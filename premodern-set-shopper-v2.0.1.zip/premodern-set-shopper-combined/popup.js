const TARGET_SETS = [
  "Scourge", "Legions", "Onslaught", "Judgment", "Torment", "Odyssey",
  "Apocalypse", "Seventh Edition", "Planeshift", "Invasion", "Prophecy",
  "Nemesis", "Mercadian Masques", "Urza's Destiny", "Classic Sixth Edition",
  "Urza's Legacy", "Urza's Saga", "Exodus", "Stronghold", "Tempest",
  "Weatherlight", "Fifth Edition", "Visions", "Mirage", "Alliances",
  "Homelands", "Chronicles", "Ice Age", "Fourth Edition"
];

const marketplace = document.getElementById("marketplace");
const applyButton = document.getElementById("apply");
const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");

const SITE_RULES = {
  tcgplayer: {
    test: url => /^https?:\/\/(www\.)?tcgplayer\.com\//i.test(url),
    message: "Open a TCGplayer Magic: The Gathering page with the Set Name filter."
  },
  manapool: {
    test: url => /^https?:\/\/(www\.)?manapool\.com\//i.test(url),
    message: "Open a ManaPool seller store page first."
  },
  comicbookstore: {
    test: url => /^https:\/\/comicbookstore\.tcgplayerpro\.com\/search\/products/i.test(url),
    message: "Open the ComicBookstore Magic search page first."
  }
};

applyButton.addEventListener("click", async () => {
  applyButton.disabled = true;
  resultsEl.hidden = true;
  const site = marketplace.value;
  statusEl.textContent = `Looking for sets on ${marketplace.options[marketplace.selectedIndex].text}…`;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !SITE_RULES[site].test(tab.url || "")) {
      throw new Error(SITE_RULES[site].message);
    }
    const injection = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [site, TARGET_SETS],
      func: async (siteName, targetSets) => {
        const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
        const normalize = value => (value || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLocaleLowerCase();
        const aliases = name => name === "Seventh Edition" ? ["Seventh Edition", "7th Edition"] : [name];

        if (siteName === "manapool") {
          const isChecked = el => el?.getAttribute("aria-checked") === "true" || el?.getAttribute("data-state") === "checked";
          const getCheckbox = id => {
            const el = id ? document.getElementById(id) : null;
            return el?.matches('button[role="checkbox"]') ? el : null;
          };
          const getLabels = () => [...document.querySelectorAll("label[data-label-root][for]")].filter(label => getCheckbox(label.getAttribute("for")));
          const getIndent = label => {
            const row = label.closest("span");
            const paddingClass = [...(row?.classList || [])].find(c => /^pl-\d+$/.test(c));
            return paddingClass ? Number(paddingClass.slice(3)) : 0;
          };
          const getSetToggle = () => [...document.querySelectorAll("button[aria-expanded]")].find(button =>
            normalize(button.querySelector("p")?.textContent || button.textContent) === "set");
          let toggle;
          for (let i=0; i<30 && !toggle; i++) { toggle=getSetToggle(); if(!toggle) await pause(150); }
          if (!toggle) return { error: "Could not locate the Set filter. Open a ManaPool seller page and try again." };
          if (toggle.getAttribute("aria-expanded") !== "true") { toggle.click(); await pause(350); }
          let labels = getLabels();
          for (let i=0; i<30 && !labels.length; i++) { await pause(150); labels=getLabels(); }

          const requested=[];
          const missingParents=[];
          for (const target of targetSets) {
            labels=getLabels();
            let index=labels.findIndex(l => l.getAttribute("for") === ({ "Seventh Edition":"7ED" }[target] || "") && normalize(l.textContent)===normalize(target));
            if(index<0) index=labels.findIndex(l => aliases(target).some(a=>normalize(l.textContent)===normalize(a)));
            if(index<0) { missingParents.push(target); continue; }
            const parent=labels[index], indent=getIndent(parent);
            requested.push({id:parent.getAttribute("for"),name:parent.textContent.trim(),kind:"parent"});
            for(let i=index+1;i<labels.length;i++) {
              const child=labels[i], childIndent=getIndent(child);
              if(childIndent<=indent) break;
              requested.push({id:child.getAttribute("for"),name:child.textContent.trim(),parent:target});
            }
          }
          const unique=[...new Map(requested.map(x=>[x.id,x])).values()];
          const selectedNow=[],alreadySelected=[],failed=[];
          for(const item of unique) {
            let checkbox=getCheckbox(item.id);
            let label=document.querySelector(`label[data-label-root][for="${CSS.escape(item.id)}"]`);
            const display=item.name+(item.parent?` — ${item.parent}`:"");
            if(!checkbox||!label) { failed.push(display); continue; }
            if(isChecked(checkbox)) { alreadySelected.push(display); continue; }
            label.scrollIntoView({block:"nearest"}); label.click();
            for(let i=0;i<20;i++){ await pause(100); checkbox=getCheckbox(item.id); if(isChecked(checkbox)) break; }
            if(!isChecked(checkbox)) { getCheckbox(item.id)?.click(); for(let i=0;i<20;i++){await pause(100);checkbox=getCheckbox(item.id);if(isChecked(checkbox))break;} }
            checkbox=getCheckbox(item.id);
            if(isChecked(checkbox)) selectedNow.push(display); else failed.push(display);
          }
          return {ok:true, parentCount:targetSets.length, requestedCount:unique.length, selectedNow,alreadySelected,failed,missingParents};
        }

        if (siteName === "tcgplayer") {
          const getBoxes=()=>[...document.querySelectorAll('.search-filter__container input.tcg-input-checkbox__input[type="checkbox"], input[id^="hfb-Set-"][type="checkbox"]')];
          const getName=input=>{
            const label=input.closest("label")||(input.id?document.querySelector(`label[for="${CSS.escape(input.id)}"]`):null);
            const text=label?.querySelector(".tcg-input-checkbox__label-text")||label;
            return (text?.textContent||"").replace(/\s+/g," ").trim();
          };
          const filterText=[...document.querySelectorAll(".hfb-popover__button__text")].find(el=>normalize(el.textContent)==="set name");
          const filterButton=filterText?.closest("button, [role='button'], .hfb-popover__button")||filterText?.parentElement?.parentElement;
          if(!filterButton) return {error:'Could not find the "Set Name" filter.'};
          let boxes=getBoxes();
          if(!boxes.length){filterButton.click();for(let i=0;i<45&&!boxes.length;i++){await pause(150);boxes=getBoxes();}}
          if(!boxes.length)return {error:"The Set Name filter opened, but no set options appeared."};
          const selectedNow=[],alreadySelected=[],found=[],missing=[];
          for(const wanted of targetSets){
            boxes=getBoxes();
            const input=boxes.find(b=>aliases(wanted).some(a=>normalize(getName(b))===normalize(a)));
            if(!input){missing.push(wanted);continue;}
            const actual=getName(input); found.push(actual);
            if(input.checked){alreadySelected.push(actual);}
            else if(!input.disabled){input.click();await pause(180);selectedNow.push(actual);}
          }
          return {ok:true,selectedNow,alreadySelected,found,missing,requestedCount:targetSets.length};
        }

        if (siteName === "comicbookstore") {
          const nameOf=label=>normalize(label.querySelector(".tcg-input-checkbox__label-text > div > div")?.textContent||label.textContent);
          const wantedNames=new Set(targetSets.flatMap(aliases).map(normalize));
          const panelForSets=()=>[...document.querySelectorAll('[id^="tcg-accordion-panel-"][id$="-content"]')]
            .find(panel=>[...panel.querySelectorAll("label")].some(label=>wantedNames.has(nameOf(label))));
          const openPanel=()=>{
            const panel=panelForSets();
            if(panel){const id=panel.getAttribute("aria-labelledby");const toggle=id&&document.getElementById(id);if(toggle?.getAttribute("aria-expanded")==="false")toggle.click();return true;}
            const toggle=[...document.querySelectorAll('[id$="-toggle"],button,[role="button"]')].find(el=>normalize(el.textContent)==="set name");
            if(toggle)toggle.click();return Boolean(toggle);
          };
          openPanel();
          let panel;
          for(let i=0;i<30;i++){panel=panelForSets();if(panel)break;await pause(250);}
          if(!panel)return {error:'The "Set Name" filter was not found.'};
          const selectedNow=[],alreadySelected=[],found=[],missing=[];
          for(const desired of targetSets){
            panel=panelForSets();
            const label=panel&&[...panel.querySelectorAll('label[for^="tcg-input-"]')]
              .find(candidate=>aliases(desired).some(alias=>normalize(nameOf(candidate))===normalize(alias)));
            if(!label){missing.push(desired);continue;}
            const actual=label.querySelector(".tcg-input-checkbox__label-text > div > div")?.textContent?.trim()||label.textContent.trim();
            const checkbox=document.getElementById(label.htmlFor);
            if(!checkbox){missing.push(desired);continue;}
            found.push(actual);
            if(checkbox.checked){alreadySelected.push(actual);continue;}
            checkbox.click();
            for(let i=0;i<10;i++){
              await pause(100);
              const refreshed=panelForSets();
              const freshLabel=refreshed&&[...refreshed.querySelectorAll('label[for^="tcg-input-"]')]
                .find(candidate=>aliases(desired).some(alias=>normalize(nameOf(candidate))===normalize(alias)));
              const freshCheckbox=freshLabel&&document.getElementById(freshLabel.htmlFor);
              if(freshCheckbox?.checked)break;
            }
            const refreshed=panelForSets();
            const freshLabel=refreshed&&[...refreshed.querySelectorAll('label[for^="tcg-input-"]')]
              .find(candidate=>aliases(desired).some(alias=>normalize(nameOf(candidate))===normalize(alias)));
            if(freshLabel&&document.getElementById(freshLabel.htmlFor)?.checked)selectedNow.push(actual);
            else missing.push(desired);
          }
          return {ok:true,selectedNow,alreadySelected,found,missing,requestedCount:targetSets.length};
        }
        return {error:"Unsupported marketplace."};
      }
    });
    const result=injection?.[0]?.result;
    if(!result)throw new Error("The page did not return a result. Please try again.");
    if(result.error)throw new Error(result.error);
    statusEl.textContent="Finished. Review the results below.";
    const selected=result.selectedNow||[], already=result.alreadySelected||[];
    const found=result.found||[...new Set([...selected,...already])];
    const failed=[...(result.failed||[]),...(result.missingParents||[]).map(n=>`${n} (parent set not found)`),...(result.missing||[])];
    document.getElementById("summary").textContent =
      `${selected.length+already.length} selected or already selected; ${found.length} sets found in the filter; ${failed.length} not found.`;
    const render=(id,items,empty)=>{
      const list=document.getElementById(id);
      if (!list) return;
      list.replaceChildren();
      const values=items.length?items:[empty];
      for(const value of values){const li=document.createElement("li");li.textContent=value;list.append(li);}
    };
    render("found",found,"No matching sets found.");
    render("selected",selected,"None");
    render("already",already,"None");
    render("failed",failed,"No missing sets.");
    resultsEl.hidden=false;
  } catch(error) {
    statusEl.textContent=error.message||"Something went wrong. Please try again.";
  } finally { applyButton.disabled=false; }
});
