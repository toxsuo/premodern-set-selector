# Premodern Set Shopper

A Chrome extension that selects Premodern-era Magic: The Gathering sets on **TCGplayer**, **ManaPool**, and **ComicBookstore**.

## Installation

1. Download and extract the ZIP file.
2. Open `chrome://extensions/` in Chrome.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `premodern-set-shopper-combined` folder.

## How to use

1. Open the marketplace you want to search.
2. For ManaPool, navigate to a seller's store page. For ComicBookstore, use its Magic: The Gathering product search page.
3. Click the Premodern Set Shopper extension icon.
4. Choose **TCGplayer**, **ManaPool**, or **ComicBookstore** from the marketplace menu.
5. Click **Select my sets**.
6. Review the results. The extension reports which sets it found, which it selected, which were already selected, and which were not found.

Existing selections are preserved. On ManaPool, the extension also selects available indented sub-set options under the requested parent sets.

## Supported sets

The extension checks for these 29 sets:

- Scourge
- Legions
- Onslaught
- Judgment
- Torment
- Odyssey
- Apocalypse
- Seventh Edition (also recognizes **7th Edition**)
- Planeshift
- Invasion
- Prophecy
- Nemesis
- Mercadian Masques
- Urza's Destiny
- Classic Sixth Edition
- Urza's Legacy
- Urza's Saga
- Exodus
- Stronghold
- Tempest
- Weatherlight
- Fifth Edition
- Visions
- Mirage
- Alliances
- Homelands
- Chronicles
- Ice Age
- Fourth Edition

## Notes

- Only sets available in the marketplace's loaded filter can be selected.
- The extension does not clear filters you have already selected.
- The extension uses each marketplace's page interface; the page must be fully loaded before you run it.
